"use client";
import { useState } from "react";
import { Btn, Card, Empty, Field, Input, Modal, PageHeader, Pill, Select, useToast } from "@/components/ui";
import { useUser } from "@/components/Session";
import { useAsync } from "@/hooks/useAsync";
import { api, send } from "@/lib/api";
import { ROLE_LABEL } from "@/lib/roles";

const ACCESS = [
  ["owner", "Everything, including users and roles."],
  ["admin", "Everything except changing owner accounts."],
  ["accountant", "All books, entries, ledger, reports and audit log. Can edit entries, but not delete or undo."],
  ["sales", "Only sales and customers. No purchases, accounts, ledger, reports or audit log. Customer bank details and balances are hidden."],
];
const when = (t) => (t ? new Date(t.endsWith("Z") ? t : t + "Z").toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "Never");

export default function Team() {
  const me = useUser(), toast = useToast();
  const { data, error, loading, reload } = useAsync(() => api("/team"));
  const [add, setAdd] = useState(false), [f, setF] = useState({ name: "", email: "", password: "", role: "sales" }), [reset, setReset] = useState(null), [pw, setPw] = useState(""), [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const isOwner = me.role === "owner";
  const manageable = (u) => u.id !== me.id && (isOwner || !["owner", "admin"].includes(u.role));
  const roles = Object.keys(ROLE_LABEL).filter((r) => isOwner || !["owner", "admin"].includes(r));

  async function patch(u, body, ok = "Saved.") {
    try { await api(`/team/${u.id}`, send("PUT", body)); toast(ok); reload(); } catch (er) { toast(er.message, true); }
  }
  async function create(e) {
    e.preventDefault(); setBusy(true);
    try { await api("/team", send("POST", f)); toast("Team member added."); setAdd(false); setF({ name: "", email: "", password: "", role: "sales" }); reload(); }
    catch (er) { toast(er.message, true); }
    setBusy(false);
  }
  async function doReset(e) {
    e.preventDefault(); setBusy(true);
    try { await api(`/team/${reset.id}`, send("PUT", { password: pw })); toast("Password reset. They are signed out everywhere."); setReset(null); setPw(""); } catch (er) { toast(er.message, true); }
    setBusy(false);
  }

  return (
    <>
      <PageHeader eyebrow="Control" title="Team and access"><Btn onClick={() => setAdd(true)}>Add team member</Btn></PageHeader>
      <Card className="mb-8">
        {loading ? <Empty>Loading…</Empty> : error ? <Empty error>{error}</Empty> : (
          <div className="tw"><table className="tbl">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead>
            <tbody>{data.map((u, i) => (
              <tr key={u.id} style={{ animationDelay: `${i * 40}ms` }}>
                <td><b>{u.name}</b>{u.id === me.id && <span className="ml-2 text-xs text-[#132622]/50">(you)</span>}</td><td>{u.email}</td>
                <td>{manageable(u) ? <Select value={u.role} onChange={(e) => patch(u, { role: e.target.value }, "Role changed.")}>{Object.keys(ROLE_LABEL).filter((r) => roles.includes(r) || r === u.role).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</Select> : <Pill>{ROLE_LABEL[u.role]}</Pill>}</td>
                <td><Pill tone={u.is_active ? "ok" : "bad"}>{u.is_active ? "Active" : "Switched off"}</Pill></td>
                <td>{when(u.last_login)}</td>
                <td className="flex gap-2">{manageable(u) && (<>
                  {u.is_active
                    ? <Btn variant="danger" className="btn-sm" onClick={() => patch(u, { is_active: false }, "Switched off.")}>Switch off</Btn>
                    : <Btn className="btn-sm" onClick={() => patch(u, { is_active: true }, "Switched on.")}>Switch on</Btn>}
                  <Btn variant="line" className="btn-sm" onClick={() => setReset(u)}>Reset password</Btn></>)}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </Card>

      <h2 className="mb-3 font-serif text-xl font-medium">What each role can do</h2>
      <div className="grid gap-4 md:grid-cols-2">{ACCESS.map(([r, t]) => <Card key={r}><b className="font-serif text-lg">{ROLE_LABEL[r]}</b><p className="mt-1 text-[14px] text-[#132622]/65">{t}</p></Card>)}</div>

      {add && (
        <Modal title="Add team member" sub="They can sign in straight away with this email and password. Staff are added here; they can’t register themselves." onClose={() => setAdd(false)}>
          <form onSubmit={create} className="grid gap-4">
            <Field label="Name"><Input required value={f.name} onChange={set("name")} /></Field>
            <Field label="Email"><Input type="email" required value={f.email} onChange={set("email")} /></Field>
            <Field label="Temporary password (8 to 72 characters)"><Input type="text" minLength={8} maxLength={72} required value={f.password} onChange={set("password")} /></Field>
            <Field label="Role"><Select value={f.role} onChange={set("role")}>{roles.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</Select></Field>
            <div className="flex gap-3"><Btn type="submit" disabled={busy}>{busy ? "Adding…" : "Add member"}</Btn><Btn variant="line" onClick={() => setAdd(false)}>Cancel</Btn></div>
          </form>
        </Modal>
      )}
      {reset && (
        <Modal title={`Reset password for ${reset.name}`} sub="They will be signed out on every device." onClose={() => setReset(null)}>
          <form onSubmit={doReset} className="grid gap-4">
            <Field label="New password (8 to 72 characters)"><Input type="text" minLength={8} maxLength={72} required autoFocus value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
            <div className="flex gap-3"><Btn type="submit" disabled={busy}>{busy ? "Resetting…" : "Reset password"}</Btn><Btn variant="line" onClick={() => setReset(null)}>Cancel</Btn></div>
          </form>
        </Modal>
      )}
    </>
  );
}