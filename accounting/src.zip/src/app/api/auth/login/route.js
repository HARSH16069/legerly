import { authProxy } from "@/lib/authproxy"
export const POST = (req) => authProxy(req, "/auth/login");