"use client";
import { useRef, useState } from "react";
import Reveal from "@/app/components/Reveal";
import { Btn, Card, Empty, Field, Input, PageHeader, Pill, Select, useToast } from "@/components/ui";
import { useAsync } from "@/hooks/useAsync";
import { api } from "@/lib/api";
import { addDays, day, diffDays, inr, payStatus, today } from "@/lib/format";

const KIND = {
  sales: { title: "Sales", party: "Customer", partyType: "customer", field: "customer_id", endpoint: "/sales-entries", ref: "Invoice no.", verb: "You collect" },
  purchase: { title: "Purchases", party: "Supplier", partyType: "supplier", field: "supplier_id", endpoint: "/purchase-entries", ref: "Supplier bill no.", verb: "You pay" },
};
const init = () => ({ date: today(), party: "", ref: "", taxable: "", rate: "18", mode: "credit", days: "30", due: addDays(today(), 30), narration: "" });

export default function EntryPage({ kind }) {
  const K = KIND[kind], toast = useToast(), fileRef = useRef(null);
  const [f, setF] = useState(init), [busy, setBusy] = useState(false);
  const parties = useAsync(() => api(`/accounts?party_type=${K.partyType}`), [kind]);
  const reg = useAsync(async () => {
    const [rows, terms] = await Promise.all([api(K.endpoint), api(`/reminders/terms?entry_type=${kind}`).catch(() => [])]);
    return { rows, tm: Object.fromEntries(terms.map((t) => [t.entry_id, t])) };
  }, [kind]);

  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const setDate = (v) => setF((s) => ({ ...s, date: v, due: addDays(v, parseInt(s.days) || 0) }));
  const setDays = (v) => setF((s) => ({ ...s, days: String(v), due: addDays(s.date, parseInt(v) || 0) }));
  const setDue = (v) => setF((s) => ({ ...s, due: v, days: String(Math.max(0, diffDays(s.date, v))) }));

  const taxable = parseFloat(f.taxable) || 0, rate = parseFloat(f.rate) || 0, gst = Math.round(taxable * rate) / 100, total = taxable + gst;
  const name = parties.data?.find((p) => String(p.id) === f.party)?.name || K.party;
  let lines = kind === "sales" ? [[name, total, 0], ["Sales", 0, taxable], ["GST Payable", 0, gst]] : [["Purchases", taxable, 0], ["GST Input", gst, 0], [name, 0, total]];
  if (f.mode === "cash") lines = lines.concat(kind === "sales" ? [["Cash", total, 0], [name, 0, total]] : [[name, total, 0], ["Cash", 0, total]]);

  async function submit(e) {
    e.preventDefault();
    if (f.mode === "credit" && diffDays(f.date, f.due) < 0) return toast("Due date can’t be before the entry date.", true);
    const fd = new FormData();
    fd.append("entry_date", f.date); fd.append(K.field, f.party); fd.append("taxable_amount", f.taxable); fd.append("gst_rate", f.rate); fd.append("payment_mode", f.mode);
    if (f.mode === "credit") { fd.append("credit_days", f.days || 0); fd.append("due_date", f.due); }
    if (f.ref.trim()) fd.append("invoice_no", f.ref.trim());
    if (f.narration.trim()) fd.append("narration", f.narration.trim());
    [...(fileRef.current?.files || [])].forEach((file) => fd.append("files", file, file.name));
    setBusy(true);
    try {
      const r = await api(K.endpoint, { method: "POST", body: fd });
      toast(`Saved entry #${r.journal_entry_id}, total ${inr(r.total_amount)}${f.mode === "credit" ? `, due ${day(f.due)}` : " (cash)"}.`);
      setF((s) => ({ ...init(), party: s.party })); if (fileRef.current) fileRef.current.value = ""; reg.reload();
    } catch (er) { toast(er.message, true); }
    setBusy(false);
  }

  return (
    <>
      <PageHeader eyebrow="Transactions" title={K.title} />
      <div className="grid items-start gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card><form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Date"><Input type="date" required value={f.date} onChange={(e) => setDate(e.target.value)} /></Field>
          <Field label={K.party}><Select required value={f.party} onChange={(e) => set("party", e.target.value)}>
            <option value="">{parties.loading ? "Loading…" : `Select ${K.party.toLowerCase()}`}</option>
            {(parties.data || []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select></Field>
          <Field label={K.ref}><Input value={f.ref} onChange={(e) => set("ref", e.target.value)} /></Field>
          <Field label="Taxable amount (₹)"><Input type="number" step="0.01" min="0.01" required value={f.taxable} onChange={(e) => set("taxable", e.target.value)} /></Field>
          <Field label="GST rate"><Select value={f.rate} onChange={(e) => set("rate", e.target.value)}>{[0, 5, 12, 18, 28].map((n) => <option key={n} value={n}>{n}%</option>)}</Select></Field>
          <Field label="Narration"><Input value={f.narration} onChange={(e) => set("narration", e.target.value)} placeholder="Optional" /></Field>
          <div className="sm:col-span-2">
            <span className="text-sm font-medium">Payment</span>
            <div className="seg mt-1.5" data-v={f.mode}>
              <button type="button" aria-pressed={f.mode === "cash"} onClick={() => set("mode", "cash")}>Cash (paid now)</button>
              <button type="button" aria-pressed={f.mode === "credit"} onClick={() => set("mode", "credit")}>Credit (pay later)</button>
            </div>
          </div>
          <div className={`fold sm:col-span-2 ${f.mode === "cash" ? "shut" : ""}`}><div>
            <div className="grid gap-4 border border-[#132622]/15 bg-[#EFEADB] p-4 sm:grid-cols-2">
              <Field label="Credit days"><Input type="number" min="0" max="365" value={f.days} onChange={(e) => setDays(e.target.value)} /></Field>
              <Field label="Due date"><Input type="date" value={f.due} onChange={(e) => setDue(e.target.value)} /></Field>
              <div className="flex flex-wrap gap-2 sm:col-span-2">{[0, 7, 15, 30, 45, 60].map((n) => <button type="button" key={n} className={`chip ${parseInt(f.days) === n ? "on" : ""}`} onClick={() => setDays(n)}>{n ? `${n} days` : "Same day"}</button>)}</div>
              <p className="text-[13px] text-[#132622]/60 sm:col-span-2">{K.verb} on {day(f.due)}.</p>
            </div>
          </div></div>
          <Field label="Bills (images or PDF)" className="sm:col-span-2"><input ref={fileRef} type="file" multiple accept="image/jpeg,image/png,image/webp,application/pdf" className="input" /></Field>
          <div className="sm:col-span-2"><Btn type="submit" disabled={busy}>{busy ? "Saving…" : `Save ${kind} entry`}</Btn></div>
        </form></Card>

        <Card className="lg:sticky lg:top-8">
          <h2 className="mb-4 font-serif text-xl font-medium">Journal that will be posted <Pill tone={f.mode === "cash" ? "ok" : "warn"}>{f.mode === "cash" ? "Cash" : "Credit"}</Pill></h2>
          <table className="tbl"><thead><tr><th></th><th className="num">Debit</th><th className="num">Credit</th></tr></thead>
            <tbody>{lines.filter((l) => l[1] > 0 || l[2] > 0 || taxable === 0).map((l, i) => <tr key={i}><td>{l[0]}</td><td className="num">{l[1] ? inr(l[1]) : ""}</td><td className="num">{l[2] ? inr(l[2]) : ""}</td></tr>)}</tbody></table>
          <div className="mt-4 grid grid-cols-[1fr_auto] gap-1 text-[14px]">
            <span>Taxable amount</span><span className="num">{inr(taxable)}</span><span>GST ({rate}%)</span><span className="num">{inr(gst)}</span>
            <span className="mt-2 border-t-2 border-[#132622] pt-3 font-serif text-[17px]">Bill total</span>
            <span key={total} className="num bump mt-2 border-t-2 border-[#132622] pt-3 text-[17px] text-[#1F5D46]">{inr(total)}</span>
          </div>
        </Card>
      </div>

      <Reveal className="mt-10"><Card>
        <h2 className="mb-4 font-serif text-xl font-medium">{K.title} register</h2>
        {reg.loading ? <Empty>Loading…</Empty> : reg.error ? <Empty error>{reg.error}</Empty> : reg.data.rows.length ? (
          <div className="tw"><table className="tbl">
            <thead><tr><th>Date</th><th>{K.ref}</th><th>{K.party}</th><th className="num">Taxable</th><th className="num">GST</th><th className="num">Total</th><th>Payment</th></tr></thead>
            <tbody>{reg.data.rows.map((r, i) => { const s = payStatus(reg.data.tm[r.id]); return (
              <tr key={r.id} style={{ animationDelay: `${Math.min(i, 12) * 30}ms` }}><td>{day(r.date)}</td><td>{r.invoice_no || "-"}</td><td>{r.party_name || "-"}</td>
                <td className="num">{inr(r.taxable_amount)}</td><td className="num">{inr(r.gst_amount)}</td><td className="num">{inr(r.total_amount)}</td><td><Pill tone={s.tone}>{s.label}</Pill></td></tr>); })}</tbody>
          </table></div>
        ) : <Empty>No {kind} entries yet.</Empty>}
      </Card></Reveal>
    </>
  );
}
